package com.te.resume_builder.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import lombok.Data;

@Data
@Entity
@Table(name = "login_details")
public class LoginInfo {

	
	@Id
	@Pattern(regexp = "^[a-zA-Z0-9+_.-]+@[a-zA-Z0-9.-]+$" , message = "please enter valid userid")
	@NotNull(message="userid cannot be null")
	@NotEmpty(message="userid connot be empty")
	private String userid;
	
	@Column
	@Pattern(regexp = "^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&-+=()])(?=\\S+$).{8,20}$", message = "please enter valid password")
	@NotNull(message="password cannot be null")
	@NotEmpty(message="password connot be empty")
	private String password;
}
