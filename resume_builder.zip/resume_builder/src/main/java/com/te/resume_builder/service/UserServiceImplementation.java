package com.te.resume_builder.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.te.resume_builder.bean.CollegeInfo;
import com.te.resume_builder.bean.ExperienceInfo;
import com.te.resume_builder.bean.IntrestInfo;
import com.te.resume_builder.bean.LoginInfo;
import com.te.resume_builder.bean.PersonalInfo;
import com.te.resume_builder.bean.ProjectInfo;
import com.te.resume_builder.bean.SchoolInfo;
import com.te.resume_builder.bean.SkillInfo;
import com.te.resume_builder.customexception.UserException;
import com.te.resume_builder.dao.CollegeDao;
import com.te.resume_builder.dao.ExperienceDao;
import com.te.resume_builder.dao.IntrestDao;
import com.te.resume_builder.dao.LoginDao;
import com.te.resume_builder.dao.PersonalDao;
import com.te.resume_builder.dao.ProjectDao;
import com.te.resume_builder.dao.SchoolDao;
import com.te.resume_builder.dao.SkillDao;
import com.te.resume_builder.dao.UserDao;

@Service
public class UserServiceImplementation implements UserService {

	@Autowired
	private UserDao userdao;
	
	@Autowired
	private PersonalDao personal;
	
	@Autowired
	private CollegeDao college;
	
	@Autowired
	private SchoolDao school;
	
	@Autowired
	private ProjectDao project;
	
	@Autowired
	private ExperienceDao experience;
	
	
	@Autowired
	private SkillDao skill;
	
	@Autowired 
	private IntrestDao intrest;

	@Autowired
	private LoginDao login;
	
	


	@Override
	@Transactional
	public Object personalRegister(PersonalInfo info) {
		if(personal.existsById(info.getEmail())) {
			throw new UserException("This email is already exist" );
		} else {
		return personal.save(info);
		}
	}


	@Override
	@Transactional
	public List<CollegeInfo> collegeRegister(List<CollegeInfo> info) {
		return college.saveAll(info);
	}


	@Override
	@Transactional
	public List<ProjectInfo> projectRegister(List<ProjectInfo> info) {
		return project.saveAll(info);
	}


	@Override
	public List<ExperienceInfo> experienceRegister(List<ExperienceInfo> info) {
		return experience.saveAll(info);
	}


	@Override
	public List<SkillInfo> skillRegister(List<SkillInfo> info) {
		return skill.saveAll(info);
	}

	@Override
	@Transactional
	public LoginInfo register(LoginInfo info) {
		if(login.existsById(info.getUserid())) {
			throw new UserException("This userid already exist");
		} else {
			return userdao.save(info);
		}
	}


	@Override
	public Object logincredential(LoginInfo info) {
		if(login.existsById(info.getUserid())) {
			if(login.getById(info.getUserid()).getPassword().equals(info.getPassword())) {
				return "Login success";
			}
			throw new UserException("Password mismatched");
		} 
		throw new UserException("Please Enter valid userid");
	}


	@Override
	public List<IntrestInfo> intrestRegister(List<IntrestInfo> info) {
		return intrest.saveAll(info);
	}


	@Override
	public List<SchoolInfo> schoolRegister(List<SchoolInfo> info) {
		
		return school.saveAll(info);
	}


	@Override
	public Object getData(String email) {
		return personal.findById(email);
	}





	

	
	
}
