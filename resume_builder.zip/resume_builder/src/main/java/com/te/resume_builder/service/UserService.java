package com.te.resume_builder.service;

import java.util.List;

import com.te.resume_builder.bean.CollegeInfo;
import com.te.resume_builder.bean.ExperienceInfo;
import com.te.resume_builder.bean.IntrestInfo;
import com.te.resume_builder.bean.LoginInfo;
import com.te.resume_builder.bean.PersonalInfo;
import com.te.resume_builder.bean.ProjectInfo;
import com.te.resume_builder.bean.SchoolInfo;
import com.te.resume_builder.bean.SkillInfo;

public interface UserService {

	public LoginInfo register(LoginInfo info);

	public Object personalRegister(PersonalInfo info);

	public Object collegeRegister(List<CollegeInfo> info);

	public Object projectRegister(List<ProjectInfo> info);

	public Object experienceRegister(List<ExperienceInfo> info);

	public Object logincredential(LoginInfo info);

	public Object skillRegister(List<SkillInfo> info);

	public Object intrestRegister(List<IntrestInfo> info);
	
	public Object schoolRegister(List<SchoolInfo> info);
	
	public Object getData(String email);

}
