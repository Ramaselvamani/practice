package com.te.resume_builder.bean;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Data;

@Data
@Entity
@Table(name = "personal_details")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class PersonalInfo {

	
	@Column
	@Pattern(regexp = "^[a-zA-Z]{3,30}$" , message = "please enter valid firstname")
	@NotEmpty(message="first name connot be empty")
	@NotNull(message="first name connot be null")
	private String firstname;
	
	@Column
	@Pattern(regexp = "^[a-zA-Z]{3,30}$" , message = "please enter valid lastname")
	@NotEmpty(message="last name connot be empty")
	@NotNull(message="last name connot be null")
	private String lastname;
	
	@Id
	@Column
	@Pattern(regexp = "^[a-zA-Z0-9+_.-]+@[a-zA-Z0-9.-]+$" , message = "please enter valid email")
	@NotEmpty(message="email connot be empty")
	@NotNull(message="email connot be null")
	private String email;
	
	@Column
	//@Size(min=10, max=10)
	//@Pattern(regexp = "(^$|[0-9]{10})", message = "please enter valid number")
	@Min(value=10)
	@NotEmpty(message="phone connot be empty")
	@NotNull(message="phone connot be null")
	private Long phone;
	
	@Column
	private String website;
	
	@Column
	private String twitter;
	
	@Column
	private String github;
	
	@Column
	private String linkedin;
	
	@Column
	private String facebook;
	
	@Column
	private String instagram;
	
	
	@OneToMany(cascade = CascadeType.ALL, mappedBy = "data1", fetch = FetchType.LAZY)
	private List<ExperienceInfo> exinfo;
	
	@OneToMany(cascade = CascadeType.ALL, mappedBy = "data2", fetch = FetchType.LAZY)
	private List<IntrestInfo> intinfo;
	
	@OneToMany(cascade = CascadeType.ALL, mappedBy = "data3", fetch = FetchType.LAZY)
	private List<ProjectInfo> proinfo;
	
	@OneToMany(cascade = CascadeType.ALL, mappedBy = "data4", fetch = FetchType.LAZY)
	private List<SchoolInfo> schoinfo;
	
	@OneToMany(cascade = CascadeType.ALL, mappedBy = "data5", fetch = FetchType.LAZY)
	private List<CollegeInfo> colinfo;
	
	@OneToMany(cascade = CascadeType.ALL, mappedBy = "data6", fetch = FetchType.LAZY)
	private List<SkillInfo> skillinfo;
	
}
