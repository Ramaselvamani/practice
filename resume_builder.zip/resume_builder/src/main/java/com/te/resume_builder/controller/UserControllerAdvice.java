package com.te.resume_builder.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.te.resume_builder.bean.UserResponse;
import com.te.resume_builder.customexception.UserException;

@RestControllerAdvice
public class UserControllerAdvice {

	@ExceptionHandler(UserException.class)
	public ResponseEntity<UserResponse> exceptionHandler(UserException exception) {
		UserResponse response = new UserResponse(true, exception.getMessage());
		return new ResponseEntity<UserResponse>(response, HttpStatus.OK);
	}
	
	@ExceptionHandler(MethodArgumentNotValidException.class)
	public ResponseEntity<UserResponse> exceptionHandler(MethodArgumentNotValidException exception) {
		UserResponse response = new UserResponse(true, exception.getFieldError().getDefaultMessage());
		return new ResponseEntity<UserResponse>(response, HttpStatus.NOT_FOUND);
	}
}
