package com.te.resume_builder.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.te.resume_builder.bean.CollegeInfo;

public interface CollegeDao extends JpaRepository<CollegeInfo, Integer>{

}
