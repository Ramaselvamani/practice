package com.te.resume_builder.customexception;

public class UserException extends RuntimeException {
	
	public UserException(String msg) {
		super(msg);
	}

}
