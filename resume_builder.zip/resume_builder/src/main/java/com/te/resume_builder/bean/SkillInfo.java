package com.te.resume_builder.bean;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Data;

@Data
@Entity
@Table(name = "skill_details")
public class SkillInfo {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer uno;
	
	@Column
	private String skill;
	
	@Column
	private String email;
	
	@JsonIgnore
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "email" , insertable = false, updatable = false)
	private PersonalInfo data6;
	
}
