package com.te.resume_builder.bean;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Data;

@Data
@Entity
@Table(name = "experience_details")
public class ExperienceInfo  {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer uno;
	
	@Column
	@NotEmpty(message="institue name connot be empty")
	@NotNull(message="institue name connot be null")
	private String institue;
	
	@Column
	@NotEmpty(message="position connot be empty")
	@NotNull(message="position connot be null")
	private String position;
	
	@Column
	@NotNull(message="duration connot be null")
	private Integer duration;
	
	@Column
	@NotEmpty(message="description connot be empty")
	@NotNull(message="description connot be null")
	private String description;
	
	@Column
	private String email;
	
	@JsonIgnore
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "email" , insertable = false, updatable = false)
	private PersonalInfo data1;
}
