package com.te.resume_builder.bean;

import java.sql.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Data;

@Data
@Entity
@Table(name = "college_details")
public class CollegeInfo {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer uno;
	
	@Column
	@NotEmpty(message="college name connot be empty")
	@NotNull(message="college name connot be null")
	private String college;
	
	@Column
	@NotEmpty(message="yop connot be empty")
	
	@NotNull(message="yop connot be null")
	private Date college_yop;
	
	@Column
	@NotEmpty(message="qualification connot be empty")
	@NotNull(message="college connot be null")
	private String colleage_qualification;
	
	@Column
	private String college_description;
	
	@Column
	private String email;
	
	@JsonIgnore
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "email" , insertable = false, updatable = false)
	private PersonalInfo data5;
	
	
}
