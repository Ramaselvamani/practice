package com.te.resume_builder.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.te.resume_builder.bean.CollegeInfo;
import com.te.resume_builder.bean.ExperienceInfo;
import com.te.resume_builder.bean.IntrestInfo;
import com.te.resume_builder.bean.LoginInfo;
import com.te.resume_builder.bean.PersonalInfo;
import com.te.resume_builder.bean.ProjectInfo;
import com.te.resume_builder.bean.SchoolInfo;
import com.te.resume_builder.bean.SkillInfo;
import com.te.resume_builder.bean.UserResponse;
import com.te.resume_builder.service.UserService;

@RestController
public class UserController {
	
	@Autowired
	public UserService service;

	
	@PostMapping(path = "/register")
	public ResponseEntity<UserResponse> toregister(@Valid @RequestBody LoginInfo info) {
		UserResponse response = new UserResponse(false, service.register(info));
		return new ResponseEntity<UserResponse>(response,HttpStatus.OK);
	}
	
	@PostMapping(path = "/personal")
	public ResponseEntity<UserResponse> toPersonalRegister(@Valid @RequestBody PersonalInfo info) {
		UserResponse response = new UserResponse(false, service.personalRegister(info));
		return new ResponseEntity<UserResponse>(response,HttpStatus.OK);
	}
	
	@PostMapping(path = "/college")
	public ResponseEntity<UserResponse> tocollegeRegister(@Valid @RequestBody List<CollegeInfo> info) {
		UserResponse response = new UserResponse(false, service.collegeRegister(info));
		return new ResponseEntity<UserResponse>(response,HttpStatus.OK);
	}
	
	@PostMapping(path = "/school")
	public ResponseEntity<UserResponse> toschoolRegister(@Valid @RequestBody List<SchoolInfo> info) {
		UserResponse response = new UserResponse(false, service.schoolRegister(info));
		return new ResponseEntity<UserResponse>(response,HttpStatus.OK);
	}
	
	@PostMapping(path = "/project")
	public ResponseEntity<UserResponse> toProjectRegister(@Valid @RequestBody List<ProjectInfo> info) {
		UserResponse response = new UserResponse(false, service.projectRegister(info));
		return new ResponseEntity<UserResponse>(response,HttpStatus.OK);
	}
	
	@PostMapping(path = "/experience")
	public ResponseEntity<UserResponse> toexperienceRegister(@Valid @RequestBody List<ExperienceInfo> info) {
		UserResponse response = new UserResponse(false, service.experienceRegister(info));
		return new ResponseEntity<UserResponse>(response,HttpStatus.OK);
	}
	
	@PostMapping(path = "/skill")
	public ResponseEntity<UserResponse> toextraRegister(@Valid @RequestBody List<SkillInfo> info) {
		UserResponse response = new UserResponse(false, service.skillRegister(info));
		return new ResponseEntity<UserResponse>(response,HttpStatus.OK);
	}
	
	@PostMapping(path = "/intrest")
	public ResponseEntity<UserResponse> tointrestRegister(@Valid @RequestBody List<IntrestInfo> info) {
		UserResponse response = new UserResponse(false, service.intrestRegister(info));
		return new ResponseEntity<UserResponse>(response,HttpStatus.OK);
	}
	
	@PostMapping(path = "/login")
	public ResponseEntity<UserResponse> login(@Valid @RequestBody LoginInfo info) {
		UserResponse response = new UserResponse(false, service.logincredential(info));
		return new ResponseEntity<UserResponse>(response,HttpStatus.OK);
	}
	
	@GetMapping(path = "/getData")
	public ResponseEntity<UserResponse> getData( @RequestParam String email) {
		UserResponse response = new UserResponse(false, service.getData(email));
		return new ResponseEntity<UserResponse>(response,HttpStatus.OK);
	}
	
}
